//
//  Seat+CoreDataClass.swift
//  FlightRider
//
//  Created by Tomi on 2019. 08. 14..
//  Copyright © 2019. Tomi. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Seat)
public class Seat: NSManagedObject {

}
